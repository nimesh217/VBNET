﻿Imports MySql.Data
Imports MySql.Data.MySqlClient
Public Class MyLectureInfo
#Region "VARIABLES"
    Dim con As MySqlConnection
    Dim cmd As MySqlCommand
    Dim adp As MySqlDataAdapter
    Dim dslecture, dsroom As DataSet
    'Dim eRoomNo As String
    Dim eLect_id As Integer
    Dim eRoomId As Integer
    Dim eClassName, eTopic, eLecturer_Name As String

#End Region

#Region "FUNCTIONS"
    Sub dbconnect()
        Try
            con = New MySqlConnection("server=localhost;user id=root;database=dbsybca")
            con.Open()
        Catch ex As Exception
            MessageBox.Show("dbconnect : " + ex.Message.ToString())
        Finally
            con.Close()
        End Try
    End Sub
    Sub fill_cmb_room()
        Try
            If con.State = ConnectionState.Closed Then
                con.Open()
            End If
            cmd = New MySqlCommand()
            cmd.Connection = con
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "select ROOM_ID,ROOM_NO from TM_ROOM"
            adp = New MySqlDataAdapter(cmd)
            dsroom = New DataSet()
            adp.Fill(dsroom)
            If dsroom.Tables(0).Rows.Count > 0 Then
                cmbRoom.DataSource = dsroom.Tables(0)
                cmbRoom.DisplayMember = "ROOM_NO"
                cmbRoom.ValueMember = "ROOM_ID"
                'For i = 0 To dsroom.Tables(0).Rows.Count - 1
                '    cmbRoom.Items.Add(dsroom.Tables(0).Rows(i).Item(0), dsroom.Tables(0).Rows(i).Item(1))

                'Next

            End If



        Catch ex As Exception
            MessageBox.Show("fill_dgv_lecture : " + ex.Message.ToString())
        Finally
            con.Close()
        End Try
    End Sub

    Sub fill_dgv_lecture()
        Try
            If con.State = ConnectionState.Closed Then
                con.Open()
            End If
            cmd = New MySqlCommand()
            cmd.Connection = con
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "select L.LECT_ID,L.CLASS_NAME,R.ROOM_ID,R.ROOM_NO,L.TOPIC,
                                L.LECTURER_NAME from LECT_DETAIL L INNER JOIN TM_ROOM R ON L.ROOM_ID=R.ROOM_ID"
            adp = New MySqlDataAdapter(cmd)
            dslecture = New DataSet()
            adp.Fill(dslecture)
            If dslecture.Tables(0).Rows.Count > 0 Then
                dgv_lecture_detail.DataSource = dslecture.Tables(0)
                dgv_lecture_detail.Columns(0).HeaderText = "LECT_ID"
                dgv_lecture_detail.Columns(0).Width = 100
                dgv_lecture_detail.Columns(1).HeaderText = "CLASS NAME"
                dgv_lecture_detail.Columns(1).Width = 200
                dgv_lecture_detail.Columns(2).Visible = False
                dgv_lecture_detail.Columns(3).HeaderText = "ROOM NO"
                dgv_lecture_detail.Columns(3).Width = 100
                dgv_lecture_detail.Columns(4).HeaderText = "TOPIC NAME"
                dgv_lecture_detail.Columns(4).Width = 100
                dgv_lecture_detail.Columns(5).HeaderText = "LECTURER NAME"
                dgv_lecture_detail.Columns(5).Width = 100

            End If


        Catch ex As Exception
            MessageBox.Show("fill_dgv_lecture : " + ex.Message.ToString())
        Finally
            con.Close()
        End Try
    End Sub

    Private Sub btn_update_Click(sender As Object, e As EventArgs) Handles btn_update.Click
        Try
            If btn_update.Text = "Update" Then
                btn_update.Text = "Save"
                btn_insert.Enabled = False
                btn_delete.Enabled = False
                txtClass.Text = eClassName
                txtLecturerName.Text = eLecturer_Name
                txtTopic.Text = eTopic
                cmbRoom.SelectedValue = eRoomId
            Else
                If con.State = ConnectionState.Closed Then
                    con.Open()
                End If
                cmd = New MySqlCommand()
                cmd.Connection = con
                cmd.CommandType = CommandType.Text
                cmd.CommandText = "update lect_detail set class_name=@class_name,room_id=@room_id,topic=@topic,lecturer_name=@lecturer_name where lect_id=@lect_id"
                cmd.Parameters.Clear()
                cmd.Parameters.AddWithValue("@lect_id", eLect_id)
                cmd.Parameters.AddWithValue("@class_name", txtClass.Text)
                cmd.Parameters.AddWithValue("@room_id", cmbRoom.SelectedValue)
                cmd.Parameters.AddWithValue("@topic", txtTopic.Text)
                cmd.Parameters.AddWithValue("@lecturer_name", txtLecturerName.Text)
                If cmd.ExecuteNonQuery > 0 Then
                    MessageBox.Show("Lecture Updated")
                End If
                fill_dgv_lecture()
                btn_update.Text = "Update"
                btn_insert.Enabled = True
                btn_delete.Enabled = True
                txtClass.Clear()
                txtLecturerName.Clear()
                txtTopic.Clear()
                cmbRoom.Select()
            End If
        Catch ex As Exception
            MessageBox.Show("btn_update_Click" + ex.Message.ToString)
        End Try

    End Sub

    Private Sub btn_cancel_Click(sender As Object, e As EventArgs) Handles btn_cancel.Click
        btn_insert.Enabled = True
        btn_insert.Text = "Insert"
        btn_update.Enabled = True
        btn_update.Text = "Update"
        btn_delete.Enabled = True
    End Sub

    Private Sub btn_delete_Click(sender As Object, e As EventArgs) Handles btn_delete.Click
        Try
            If con.State = ConnectionState.Closed Then
                con.Open()
            End If
            cmd = New MySqlCommand()
            cmd.Connection = con
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "delete from lect_detail where lect_id=@lect_id"
            cmd.Parameters.Clear()
            cmd.Parameters.AddWithValue("@lect_id", eLect_id)
            If cmd.ExecuteNonQuery > 0 Then
                MessageBox.Show("Lecture Deleted")
            End If
            fill_dgv_lecture()
        Catch ex As Exception
            MessageBox.Show("btn_delete_Click : " + ex.Message.ToString)
        Finally

        End Try
    End Sub

    Private Sub btn_insert_Click(sender As Object, e As EventArgs) Handles btn_insert.Click
        Try
            If btn_insert.Text = "Insert" Then
                txtClass.Text = ""
                cmbRoom.SelectedIndex = 0
                txtTopic.Text = ""
                txtLecturerName.Text = ""

                btn_insert.Text = "Save"
                btn_delete.Enabled = False
                btn_update.Enabled = False
            Else
                If con.State = ConnectionState.Closed Then
                    con.Open()
                End If
                cmd = New MySqlCommand()
                cmd.Connection = con
                cmd.CommandType = CommandType.Text
                cmd.CommandText = "insert into lect_detail (class_name,room_id,topic,lecturer_name)values (@class_name,@room_id,@topic,@lecturer_name)"
                cmd.Parameters.Clear()

                cmd.Parameters.AddWithValue("@class_name", txtClass.Text)
                cmd.Parameters.AddWithValue("@room_id", cmbRoom.SelectedValue)
                cmd.Parameters.AddWithValue("@topic", txtTopic.Text)
                cmd.Parameters.AddWithValue("@lecturer_name", txtLecturerName.Text)
                If (cmd.ExecuteNonQuery > 0) Then
                    MessageBox.Show("Lecture Details Added")
                End If
                txtClass.Text = ""
                cmbRoom.SelectedIndex = 0
                txtTopic.Text = ""
                txtLecturerName.Text = ""
                btn_insert.Text = "Insert"
                btn_delete.Enabled = True
                btn_update.Enabled = True
                fill_dgv_lecture()
            End If
        Catch ex As Exception
            MessageBox.Show("btn_insert_Click : " + ex.Message.ToString())
        Finally
            con.Close()
        End Try

    End Sub


#End Region

#Region "EVENTS & METHODS"
    Private Sub MyLectureInfo_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            dbconnect()
            fill_dgv_lecture()
            fill_cmb_room()
        Catch ex As Exception
            MessageBox.Show("MyLectureInfo_Load : " + ex.Message.ToString())
        Finally
            con.Close()
        End Try
    End Sub

    Private Sub dgv_lecture_detail_Click(sender As Object, e As EventArgs) Handles dgv_lecture_detail.Click
        eLect_id = dgv_lecture_detail.CurrentRow().Cells(0).Value
        eClassName = dgv_lecture_detail.CurrentRow().Cells(1).Value
        eRoomId = dgv_lecture_detail.CurrentRow().Cells(2).Value
        eTopic = dgv_lecture_detail.CurrentRow().Cells(4).Value
        eLecturer_Name = dgv_lecture_detail.CurrentRow().Cells(5).Value
    End Sub
#End Region


End Class