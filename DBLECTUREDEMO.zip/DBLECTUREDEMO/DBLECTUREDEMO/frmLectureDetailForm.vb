﻿Public Class frmLectureDetailForm

End Class