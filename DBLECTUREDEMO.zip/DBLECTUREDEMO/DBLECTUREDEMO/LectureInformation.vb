﻿Imports MySql.Data
Imports MySql.Data.MySqlClient
Public Class RoomInformation
#Region "variables"
    Dim con As MySqlConnection
    Dim cmd As MySqlCommand
    Dim adp As MySqlDataAdapter
    Dim dsroom As DataSet
    Dim eRoomId As Integer
    Dim eRoomNo As String
    Dim eIsAvailable As Boolean
#End Region

#Region "functions"
    Sub dbconnect()
        Try
            con = New MySqlConnection("server=localhost;user id=root;database=dbsybca")
            con.Open()
        Catch ex As Exception
            MessageBox.Show("dbconnect : " + ex.Message.ToString())
        Finally
            con.Close()
        End Try
    End Sub




    Sub fill_dgv_room()
        Try
            If con.State = ConnectionState.Closed Then
                con.Open()
            End If
            cmd = New MySqlCommand()
            cmd.Connection = con
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "select ROOM_ID,ROOM_NO,IS_AVAILABLE from TM_ROOM"
            adp = New MySqlDataAdapter(cmd)
            dsroom = New DataSet()
            adp.Fill(dsroom)
            If dsroom.Tables(0).Rows.Count > 0 Then
                dgv_room.DataSource = dsroom.Tables(0)
                dgv_room.Columns(0).HeaderText = "ROOM_ID"
                dgv_room.Columns(0).Width = 100
                dgv_room.Columns(1).HeaderText = "ROOM_NO"
                dgv_room.Columns(1).Width = 200
                dgv_room.Columns(2).HeaderText = "is Available"
                dgv_room.Columns(2).Width = 100

            End If


        Catch ex As Exception
            MessageBox.Show("fill_dgv_room : " + ex.Message.ToString())
        Finally
            con.Close()
        End Try
    End Sub
#End Region

#Region "EVENTS"
    Private Sub btn_insert_Click(sender As Object, e As EventArgs) Handles btn_insert.Click
        Try
            If btn_insert.Text = "Insert" Then
                txtRoomNo.Text = ""
                btn_insert.Text = "Save"
                btn_delete.Enabled = False
                btn_update.Enabled = False
            Else
                If con.State = ConnectionState.Closed Then
                    con.Open()
                End If
                cmd = New MySqlCommand()
                cmd.Connection = con
                cmd.CommandType = CommandType.Text
                cmd.CommandText = "insert into tm_room (room_no,is_available)values (@room_no,@is_available)"
                cmd.Parameters.Clear()
                cmd.Parameters.AddWithValue("@room_no", txtRoomNo.Text)
                cmd.Parameters.AddWithValue("@is_available", True)
                If (cmd.ExecuteNonQuery > 0) Then
                    MessageBox.Show("Room Added")
                End If
                txtRoomNo.Text = ""
                btn_insert.Text = "Insert"
                btn_delete.Enabled = True
                btn_update.Enabled = True
                fill_dgv_room()
            End If
        Catch ex As Exception
            MessageBox.Show("btn_insert_Click : " + ex.Message.ToString())
        Finally
            con.Close()
        End Try


    End Sub

    Private Sub RoomInformation_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            dbconnect()
            fill_dgv_room()
        Catch ex As Exception
            MessageBox.Show("RoomInformation_Load : " + ex.Message.ToString())
        Finally
            con.Close()
        End Try
    End Sub

    Private Sub btn_delete_Click(sender As Object, e As EventArgs) Handles btn_delete.Click
        If eRoomId > 0 Then
            If con.State = ConnectionState.Closed Then
                con.Open()
            End If
            cmd = New MySqlCommand()
            cmd.Connection = con
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "delete from tm_room where room_id=@room_id"
            cmd.Parameters.Clear()
            cmd.Parameters.AddWithValue("@room_id", eRoomId)

            If (cmd.ExecuteNonQuery > 0) Then
                MessageBox.Show("Room Deleted")
            End If
            txtRoomNo.Text = ""
            btn_delete.Enabled = True
            btn_update.Enabled = True
            fill_dgv_room()
        End If
    End Sub

    Private Sub dgv_room_Click(sender As Object, e As EventArgs) Handles dgv_room.Click, dgv_lecture_detail.Click
        eRoomId = dgv_room.CurrentRow().Cells(0).Value
        eRoomNo = dgv_room.CurrentRow().Cells(1).Value
        eIsAvailable = dgv_room.CurrentRow().Cells(2).Value
    End Sub
#End Region



End Class