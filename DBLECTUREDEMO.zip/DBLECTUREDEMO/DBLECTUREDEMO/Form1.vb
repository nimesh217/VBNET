﻿Public Class Form1
    Private Sub AddRoomToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AddRoomToolStripMenuItem.Click
        RoomInformation.Show()
    End Sub

    Private Sub AddLectureDetailToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AddLectureDetailToolStripMenuItem.Click
        MyLectureInfo.Show()
    End Sub
End Class
