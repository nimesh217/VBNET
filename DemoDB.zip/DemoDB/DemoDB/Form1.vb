﻿Imports System.Data
Imports System.Data.OleDb
Imports MySql.Data
Imports MySql.Data.MySqlClient



Public Class Form1

#Region "VARIABLES"
    'Dim con As OleDbConnection
    Dim con As MySqlConnection
    Dim cmd As MySqlCommand
    Dim dsuser As DataSet
    Dim adp As MySqlDataAdapter
    Dim tuserid As Integer = 0
    Dim tname, temail, tmobile, tpassword As String
    Dim editRow As DataRow

#End Region

#Region "FUNCTIONS"
    Sub dbconnect()
        Try
            con = New MySqlConnection()
            con.ConnectionString = "server=localhost;user id=root;database=dbsybca"
            'server=localhost;user id=root;database=dbsybca
            con.Open()
        Catch ex As Exception
            MessageBox.Show("dbconnect : " + ex.Message.ToString())
        Finally
            If con.State = ConnectionState.Open Then
                con.Close()
            End If
        End Try
    End Sub

    Sub fill_datagrid_user()
        Try
            'fill the datagridview by select query
            If con.State = ConnectionState.Closed Then
                con.Open()
            End If
            cmd = New MySqlCommand()
            cmd.Connection = con
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "select userid,name,email,mobile,password from tmuser"
            adp = New MySqlDataAdapter(cmd)
            dsuser = New DataSet()
            adp.Fill(dsuser)
            If (dsuser.Tables(0).Rows.Count > 0) Then
                datagrid_user.DataSource = dsuser.Tables(0)
                'datagrid_user.Columns(0).Visible = False
                datagrid_user.Columns(0).HeaderText = "UserId"
                datagrid_user.Columns(0).Width = 100
                datagrid_user.Columns(1).HeaderText = "Name"
                datagrid_user.Columns(1).Width = 150
                datagrid_user.Columns(2).HeaderText = "email"
                datagrid_user.Columns(2).Width = 200
                datagrid_user.Columns(3).HeaderText = "mobile"
                datagrid_user.Columns(3).Width = 100
                datagrid_user.Columns(4).HeaderText = "Password"
                datagrid_user.Columns(4).Width = 100


            End If

        Catch ex As Exception
            MessageBox.Show("fill_datagrid_user : " + ex.Message.ToString())
        Finally
            If con.State = ConnectionState.Open Then
                con.Close()
            End If
        End Try
    End Sub
#End Region

#Region "EVENTS & METHODS"
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            dbconnect()
            fill_datagrid_user()

        Catch ex As Exception
            MessageBox.Show("Form1_Load : " + ex.Message.ToString())

        End Try

    End Sub

    Private Sub btn_insert_Click(sender As Object, e As EventArgs) Handles btn_insert.Click
        Try
            If btn_insert.Text = "Insert" Then
                btn_insert.Text = "Save"
                btn_update.Enabled = False
                btn_delete.Enabled = False
                txtName.Clear()
                txtEmail.Clear()
                txtMobile.Clear()
                txtPassword.Clear()
                txtName.Select()
            Else
                ' btn_insert = "Save"

                'insert the data
                If con.State = ConnectionState.Closed Then
                    con.Open()
                End If
                cmd = New MySqlCommand()
                cmd.Connection = con
                cmd.CommandType = CommandType.Text
                cmd.CommandText = "insert into tmuser (name,email,mobile,password) values (@name,@email,@mobile,@password)"
                cmd.Parameters.Clear()
                cmd.Parameters.AddWithValue("@name", txtName.Text)
                cmd.Parameters.AddWithValue("@email", txtEmail.Text)
                cmd.Parameters.AddWithValue("@mobile", txtMobile.Text)
                cmd.Parameters.AddWithValue("@password", txtPassword.Text)
                If (cmd.ExecuteNonQuery > 0) Then
                    MessageBox.Show("Record Inserted")
                End If
                btn_update.Enabled = True
                btn_delete.Enabled = True
                btn_insert.Text = "Insert"
                txtName.Clear()
                txtEmail.Clear()
                txtMobile.Clear()
                txtPassword.Clear()
                txtName.Select()
                fill_datagrid_user()
            End If
        Catch ex As Exception
            MessageBox.Show("btn_insert : " + ex.Message.ToString())
        Finally
            If con.State = ConnectionState.Open Then
                con.Close()
            End If

        End Try

    End Sub

    Private Sub btn_update_Click(sender As Object, e As EventArgs) Handles btn_update.Click
        Try

            If btn_update.Text = "Update" Then
                txtName.Text = tname
                txtEmail.Text = temail
                txtMobile.Text = tmobile
                txtPassword.Text = tpassword
                btn_update.Text = "Save"
                btn_insert.Enabled = False
                btn_delete.Enabled = False
            Else
                'fire upadte query
                'insert the data
                If con.State = ConnectionState.Closed Then
                    con.Open()
                End If
                cmd = New MySqlCommand()
                cmd.Connection = con
                cmd.CommandType = CommandType.Text
                cmd.CommandText = "update tmuser set name=@name,email=@email,mobile=@mobile,password=@password where userid=@userid"
                cmd.Parameters.Clear()
                cmd.Parameters.AddWithValue("@userid", tuserid)
                cmd.Parameters.AddWithValue("@name", txtName.Text)
                cmd.Parameters.AddWithValue("@email", txtEmail.Text)
                cmd.Parameters.AddWithValue("@mobile", txtMobile.Text)
                cmd.Parameters.AddWithValue("@password", txtPassword.Text)
                If (cmd.ExecuteNonQuery > 0) Then
                    MessageBox.Show("Record Updated..")
                End If
                btn_update.Text = "Update"
                btn_insert.Enabled = True
                btn_delete.Enabled = True
                txtName.Clear()
                txtEmail.Clear()
                txtMobile.Clear()
                txtPassword.Clear()
                txtName.Select()
            End If
            fill_datagrid_user()
        Catch ex As Exception
            MessageBox.Show("btn_update_Click :" + ex.Message.ToString())
        Finally
            If con.State = ConnectionState.Open Then
                con.Close()
            End If
        End Try

    End Sub

    Private Sub btn_delete_Click(sender As Object, e As EventArgs) Handles btn_delete.Click
        'delete query

        Try
            If con.State = ConnectionState.Closed Then
                con.Open()
            End If
            cmd = New MySqlCommand()
            cmd.Connection = con
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "delete from tmuser where userid=@userid"
            cmd.Parameters.Clear()
            cmd.Parameters.AddWithValue("@userid", tuserid)
            If cmd.ExecuteNonQuery() > 0 Then
                MessageBox.Show("Record Deleted")
                fill_datagrid_user()
            End If

        Catch ex As Exception
            MessageBox.Show("btn_delete_Click : " + ex.Message.ToString)
        Finally
            If con.State = ConnectionState.Open Then
                con.Close()
            End If
        End Try


    End Sub



    Private Sub datagrid_user_Click(sender As Object, e As EventArgs) Handles datagrid_user.Click
        'MessageBox.Show(datagrid_user.CurrentRow().Cells(0).Value)
        tuserid = datagrid_user.CurrentRow().Cells(0).Value
        tname = datagrid_user.CurrentRow().Cells(1).Value
        temail = datagrid_user.CurrentRow().Cells(2).Value
        tmobile = datagrid_user.CurrentRow().Cells(3).Value
        tpassword = datagrid_user.CurrentRow().Cells(4).Value

    End Sub

    Private Sub btn_cancel_Click(sender As Object, e As EventArgs) Handles btn_cancel.Click
        btn_insert.Text = "Insert"
        btn_update.Enabled = True
        btn_delete.Enabled = True
        btn_update.Text = "Update"
        btn_insert.Enabled = True
        txtName.Clear()
        txtEmail.Clear()
        txtMobile.Clear()
        txtPassword.Clear()
        txtName.Select()
    End Sub


#End Region



End Class
