﻿Imports MySql.Data
Imports MySql.Data.MySqlClient
Public Class Form1
    Dim con As MySqlConnection
    Dim cmd As MySqlCommand
    Dim adp As MySqlDataAdapter
    Dim ds As DataSet
    Dim dsid As Integer ' delete
    Dim dsname, dclass, dmobile As String

    Public Sub dbconnect()
        Try
            con = New MySqlConnection()
            con.ConnectionString = "server=localhost;user id=root;database=dbsybca"
            con.Open()
        Catch ex As Exception
            MessageBox.Show("dbconnect : " & ex.Message)
        Finally
            con.Close()
        End Try
    End Sub

    Public Sub fillgridviewstudent()
        Try
            If con.State = ConnectionState.Closed Then
                con.Open()
            End If
            cmd = New MySqlCommand()
            cmd.Connection = con
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "select sid,sname,class,mobile from student"
            adp = New MySqlDataAdapter(cmd)
            ds = New DataSet()
            adp.Fill(ds)
            datagridstudent.DataSource = ds.Tables(0)
            ' datagridstudent.Columns(0).Visible = False
            datagridstudent.Columns(0).Width = 100
            datagridstudent.Columns(0).HeaderText = "SID"
            datagridstudent.Columns(1).Width = 100
            datagridstudent.Columns(1).HeaderText = "SNAME"
            datagridstudent.Columns(2).Width = 100
            datagridstudent.Columns(2).HeaderText = "CLASS"
            datagridstudent.Columns(3).Width = 100
            datagridstudent.Columns(3).HeaderText = "Mobile"
        Catch ex As Exception
            MessageBox.Show("fillgridviewstudent : " & ex.Message)
        Finally
            con.Close()
        End Try
    End Sub

    Private Sub btnInsert_Click(sender As Object, e As EventArgs) Handles btnInsert.Click
        Try
            If btnInsert.Text = "Add" Then
                btnInsert.Text = "Insert"
                btnDelete.Enabled = False
                btnSave.Enabled = False
                txtsname.Clear()
                txtclass.Clear()
                txtmobile.Clear()
                txtsname.Select()
            Else
                If con.State = ConnectionState.Closed Then
                    con.Open()
                End If
                cmd = New MySqlCommand()
                cmd.Connection = con
                cmd.CommandType = CommandType.Text
                cmd.CommandText = "insert into student (sname,class,mobile)values (@sname,@class,@mobile)"
                cmd.Parameters.Clear()
                cmd.Parameters.AddWithValue("@sname", txtsname.Text)
                cmd.Parameters.AddWithValue("@class", txtclass.Text)
                cmd.Parameters.AddWithValue("@mobile", txtmobile.Text)
                Dim res As Integer
                res = cmd.ExecuteNonQuery()
                If res <> -1 Then
                    MessageBox.Show("Recored Added")
                Else
                    MessageBox.Show("Problem in insert")
                End If
                btnInsert.Text = "Add"
                btnDelete.Enabled = True
                btnSave.Enabled = True
                txtsname.Clear()
                txtclass.Clear()
                txtmobile.Clear()
                txtsname.Select()
                fillgridviewstudent()
            End If
        Catch ex As Exception
            MessageBox.Show("btnInsert_Click : " & ex.Message)
        Finally
            con.Close()
        End Try
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            dbconnect()
            fillgridviewstudent()
        Catch ex As Exception
            MessageBox.Show("Form1_Load : " & ex.Message)
        Finally
            con.Close()
        End Try

    End Sub

    Private Sub datagridstudent_Click(sender As Object, e As EventArgs) Handles datagridstudent.Click
        dsid = datagridstudent.CurrentRow().Cells(0).Value
        dsname = datagridstudent.CurrentRow().Cells(1).Value
        dclass = datagridstudent.CurrentRow().Cells(2).Value
        dmobile = datagridstudent.CurrentRow().Cells(3).Value
        'MsgBox(dsid.ToString())
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        txtsname.Clear()
        txtclass.Clear()
        txtmobile.Clear()
        btnDelete.Enabled = True
        btnInsert.Enabled = True
        btnSave.Enabled = True
        btnInsert.Text = "Add"
        btnSave.Text = "Edit"
        dsid = 0
        dsname = dclass = dmobile = ""
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        adp.Update(ds)
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Try
            If dsid > 0 Then
                If con.State = ConnectionState.Closed Then
                    con.Open()
                End If
                cmd = New MySqlCommand()
                cmd.Connection = con
                cmd.CommandType = CommandType.Text
                cmd.CommandText = "delete from student where sid=@sid"
                cmd.Parameters.Clear()
                cmd.Parameters.AddWithValue("@sid", dsid)
                Dim res As Integer
                res = cmd.ExecuteNonQuery()
                If res <> -1 Then
                    MessageBox.Show("Recored Deleted")
                End If
                fillgridviewstudent()
            End If
        Catch ex As Exception
            MessageBox.Show("btnDelete_Click : " & ex.Message)
        Finally
            con.Close()
        End Try
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If btnSave.Text = "Edit" Then
            btnSave.Text = "Save"
            btnInsert.Enabled = False
            btnDelete.Enabled = False
            txtsname.Text = dsname
            txtclass.Text = dclass
            txtmobile.Text = dmobile
        Else
            If con.State = ConnectionState.Closed Then
                con.Open()
            End If
            cmd = New MySqlCommand()
            cmd.Connection = con
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "update student set sname=@sname,class=@class,mobile=@mobile where sid=@sid"
            cmd.Parameters.Clear()
            cmd.Parameters.AddWithValue("@sid", dsid)
            cmd.Parameters.AddWithValue("@sname", txtsname.Text)
            cmd.Parameters.AddWithValue("@class", txtclass.Text)
            cmd.Parameters.AddWithValue("@mobile", txtmobile.Text)
            Dim res As Integer
            res = cmd.ExecuteNonQuery
            If res <> -1 Then
                MessageBox.Show("Recored Updated")
            End If
            fillgridviewstudent()
            btnSave.Text = "Edit"
            btnInsert.Enabled = True
            btnDelete.Enabled = True
            txtsname.Clear()
            txtclass.Clear()
            txtmobile.Clear()
        End If
    End Sub
End Class
